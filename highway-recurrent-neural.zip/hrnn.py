x = '''0.8238   0.8749  0.4995  0.7778  0.061
0.8081  0.754   0.8465  0.8513  0.7822
0.7389  0.9166  0.908   0.8365  0.8266
0.8425  0.9074  0.9174  0.9009  0.785
0.8099  0.8804  0.8787  0.8928  0.2125
0.9532  0.9111  0.9127  0.9561  0.9708
0.9461  0.9625  0.9567  0.946   0.9566
0.9403  0.9375  0.9543  0.9134  0.8953
0.9132  0.9458  0.8762  0.8859  0.7797
0.9199  0.9359  0.9407  0.9172  0.9513
0.9307  0.9355  0.9102  0.938   0.9377
0.9563  0.9641  0.9573  0.9648  0.9695  '''

data = x.split('\n')
s = data[0:4]
l = data[4:8]
g = data[8:]

labels = {
        0: 'Vanilla',
        1: 'Residual',
        2: 'Highway',
        3: 'Highway w/ limits',
}

import matplotlib.pyplot as plt

def plotRNN(x, out):
    for i, row in enumerate(x):
        print row
        plt.plot(map(float, row.split()), label=labels[i])

    plt.legend(loc='best')
    plt.axhline(1.0, color='black')
    plt.ylim(0.6, 1.1)
    plt.ylabel('Average Precision')
    plt.xlabel('# of hidden layers')
    plt.xticks([0, 1, 2, 3, 4], ['2', '3', '4', '5', '10'])
    plt.savefig(out)


plt.figure()
plt.title('Simple RNN')
plotRNN(s, 'srnn.pdf')

plt.figure()
plt.title('LSTM RNN')
plotRNN(l, 'lstm.pdf')

plt.figure()
plt.title('GRU RNN')
plotRNN(g, 'gru.pdf')
